/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const parse_chat_wasm: (a: number, b: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
