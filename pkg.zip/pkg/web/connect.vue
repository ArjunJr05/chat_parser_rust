<template>
  <div class="connector-panel">
    <h1>WhatsApp Rust Bridge</h1>
    <input type="file" @change="handleUpload" accept=".zip" />
    
    <div v-if="loading">Processing in Rust (WASM)...</div>
    
    <div v-if="chatData" class="output-log">
      <h2>Chat: {{ chatData.chatName }}</h2>
      <ul>
        <li v-for="(msg, idx) in chatData.messages" :key="idx">
          <strong>{{ msg.text.base.sender }}:</strong> {{ msg.text.text }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
// 1. Import the generated WASM glue code
import init, { parse_chat_wasm } from '../../../pkg/rust_core.js';
// 2. Import Protobuf decoder for Web
import { WhatsAppExport } from './proto-generated/messages_pb.js';

const chatData = ref(null);
const loading = ref(false);

onMounted(async () => {
  // Initialize WASM module
  await init();
});

const handleUpload = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  loading.value = true;
  const reader = new FileReader();

  reader.onload = async (e) => {
    // 3. Convert file to Uint8Array (Input for Rust)
    const bytes = new Uint8Array(e.target.result);

    // 4. Execute Rust code in the Browser thread
    const protoOutput = parse_chat_wasm(bytes);

    if (protoOutput.length > 0) {
      // 5. Decode binary Output and take it as Input for the UI
      chatData.value = WhatsAppExport.deserializeBinary(protoOutput).toObject();
      console.log("Parsed using Rust WASM:", chatData.value);
    }
    
    loading.value = false;
  };

  reader.readAsArrayBuffer(file);
};
</script>

<style scoped>
.connector-panel {
  padding: 20px;
  background: #f4f4f4;
  border-radius: 8px;
}
.output-log {
  margin-top: 20px;
  text-align: left;
  background: white;
  padding: 10px;
}
li { list-style: none; margin-bottom: 5px; }
</style>
